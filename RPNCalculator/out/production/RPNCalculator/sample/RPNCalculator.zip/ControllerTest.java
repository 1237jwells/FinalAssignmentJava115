package sample;

import org.junit.Assert;
import org.junit.Test;
import static org.junit.Assert.*;

public class ControllerTest {
    @Test
    public void actionEnter() throws Exception {
    }

//    @Test
//    public void actionPlus() throws Exception {
//        String expValue = "2 3 4 8 5 + - * /";
//        Double result = Controller.actionPlus(expValue);
//        Assert.assertNotNull(String.valueOf(result), "Expression " + expValue + " is supposed to be valid");
//
//    }

    @Test
    public void actionMinus() throws Exception {
    }

    @Test
    public void actionMultiply() throws Exception {
    }

    @Test
    public void actionDivide() throws Exception {
    }

    @Test
    public void actionOne() throws Exception {
    }

    @Test
    public void actionTwo() throws Exception {
    }

    @Test
    public void actionThree() throws Exception {
    }

    @Test
    public void actionFour() throws Exception {
    }

    @Test
    public void actionFive() throws Exception {
    }

    @Test
    public void actionSix() throws Exception {
    }

    @Test
    public void actionSeven() throws Exception {
    }

    @Test
    public void actionEight() throws Exception {
    }

    @Test
    public void actionNine() throws Exception {
    }

    @Test
    public void actionZero() throws Exception {
    }

    @Test
    public void actionStore() throws Exception {
    }

    @Test
    public void actionRecall() throws Exception {
    }

    @Test
    public void actionPoint() throws Exception {
    }

    @Test
    public void actionClear() throws Exception {
    }

    @Test
    public void setStack() throws Exception {
    }

    @Test
    public void initialize() throws Exception {
    }

    @Test
    public void start() throws Exception {
    }

}