package sample;

public @interface Override {
}
